import 'package:flutter/material.dart';

void main() => runApp(BigDawgApp());

class BigDawgApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BIGDAWG',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('BIGDAWG Dog Training')),
      body: Center(
        child: Text(
          'Welcome to BIGDAWG! 🐶',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
